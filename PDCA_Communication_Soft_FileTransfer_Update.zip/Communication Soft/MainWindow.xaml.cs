﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace CommunicationSoft
{
    public partial class MainWindow : Window
    {
        private sealed class MachineRow
        {
            public int Number;
            public TextBox NameBox, IpBox, PortBox;
            public TextBlock Status;
            public List<string> Queue = new List<string>();
        }
        private readonly List<MachineRow> _machines = new List<MachineRow>();
        private readonly DispatcherTimer _clock = new DispatcherTimer();
        private readonly string _settingsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "machines.txt");
        private readonly List<string> _fileQueue = new List<string>();
        private readonly string _logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs", "communication-log.txt");
        private bool _sending;

        public MainWindow()
        {
            InitializeComponent();
            for (int i = 1; i <= 6; i++) AddMachineRow(i);
            LoadSettings();
            SerialBox.KeyDown += SerialBox_KeyDown;
            _clock.Interval = TimeSpan.FromSeconds(1);
            _clock.Tick += (s, e) => ClockText.Text = "Date: " + DateTime.Now.ToString("dd-MM-yyyy") + "    Time: " + DateTime.Now.ToString("HH:mm:ss");
            _clock.Start();
            ClockText.Text = "Date: " + DateTime.Now.ToString("dd-MM-yyyy") + "    Time: " + DateTime.Now.ToString("HH:mm:ss");
        }

        private void AddMachineRow(int number)
        {
            var grid = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(50) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(100) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            var row = new MachineRow { Number = number };
            var num = new TextBlock { Text = number.ToString(), FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center };
            row.NameBox = new TextBox { Text = "Machine " + number, IsReadOnly = true, IsReadOnlyCaretVisible = false };
            row.IpBox = new TextBox { Text = "192.168.1." + (100 + number) };
            row.PortBox = new TextBox { Text = "56379" };
            row.Status = new TextBlock { Text = "Not tested", Foreground = System.Windows.Media.Brushes.LightGray };
            var test = new Button { Content = "Test" };
            test.Click += async (s, e) => await TestMachineAsync(row);
            var save = new Button { Content = "Save" };
            save.Click += (s, e) => { SaveSettings(); StatusText.Text = "Saved settings for " + row.NameBox.Text + "."; };
            Grid.SetColumn(num, 0); Grid.SetColumn(row.NameBox, 1); Grid.SetColumn(row.IpBox, 2); Grid.SetColumn(row.PortBox, 3); Grid.SetColumn(row.Status, 4);
            var actions = new StackPanel { Orientation = Orientation.Horizontal };
            actions.Children.Add(test); actions.Children.Add(save); Grid.SetColumn(actions, 5);
            grid.Children.Add(num); grid.Children.Add(row.NameBox); grid.Children.Add(row.IpBox); grid.Children.Add(row.PortBox); grid.Children.Add(row.Status); grid.Children.Add(actions);
            MachineRows.Children.Add(grid); _machines.Add(row);
        }

        private void LoadSettings()
        {
            try
            {
                if (!File.Exists(_settingsPath))
                {
                    string legacy = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "machines.csv");
                    if (!File.Exists(legacy)) return;
                    foreach (var line in File.ReadAllLines(legacy).Skip(1))
                    {
                        var p = line.Split('|'); if (p.Length < 4) continue;
                        int n; if (!int.TryParse(p[0], out n) || n < 1 || n > 6) continue;
                        var r = _machines[n - 1]; r.NameBox.Text = "Machine " + n; r.IpBox.Text = p[2]; r.PortBox.Text = p[3];
                    }
                    return;
                }
                foreach (var line in File.ReadAllLines(_settingsPath).Skip(1))
                {
                    var p = line.Split('|'); if (p.Length < 4) continue;
                    int n; if (!int.TryParse(p[0], out n) || n < 1 || n > 6) continue;
                    var r = _machines[n - 1]; r.NameBox.Text = p[1]; r.IpBox.Text = p[2]; r.PortBox.Text = p[3];
                }
            }
            catch (Exception ex) { StatusText.Text = "Settings load error: " + ex.Message; }
        }
        private void SaveSettings()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_settingsPath));
            var lines = new List<string> { "# Machine configuration (text format)", "Machine|Name|IP|Port" };
            foreach (var r in _machines) lines.Add(r.Number + "|" + Clean(r.NameBox.Text) + "|" + Clean(r.IpBox.Text) + "|" + Clean(r.PortBox.Text));
            File.WriteAllLines(_settingsPath, lines, Encoding.UTF8);
        }
        private static string Clean(string s) { return (s ?? "").Replace("|", " ").Replace("\r", " ").Replace("\n", " ").Trim(); }
        private void SaveSettings_Click(object sender, RoutedEventArgs e) { try { SaveSettings(); StatusText.Text = "Machine names, IPs and ports saved."; } catch (Exception ex) { StatusText.Text = "Save failed: " + ex.Message; } }

        private async Task<string> SendCommandAsync(MachineRow row, string command)
        {
            int port; if (!int.TryParse(row.PortBox.Text.Trim(), out port) || port < 1 || port > 65535) throw new InvalidOperationException("Invalid port for " + row.NameBox.Text);
            using (var client = new TcpClient())
            {
                client.NoDelay = true;
                await client.ConnectAsync(row.IpBox.Text.Trim(), port);
                using (var stream = client.GetStream())
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true })
                {
                    await writer.WriteLineAsync(command);
                    var responseTask = reader.ReadLineAsync();
                    var completed = await Task.WhenAny(responseTask, Task.Delay(2500));
                    if (completed != responseTask) return "No response (command may still have been delivered).";
                    return await responseTask;
                }
            }
        }
        private async Task TestMachineAsync(MachineRow row)
        {
            try { var result = await SendCommandAsync(row, "PING"); row.Status.Text = result.StartsWith("OK") ? "Online" : "Check response"; row.Status.Foreground = result.StartsWith("OK") ? System.Windows.Media.Brushes.LimeGreen : System.Windows.Media.Brushes.Red; StatusText.Text = row.NameBox.Text + ": " + result; }
            catch (Exception ex) { row.Status.Text = "Offline"; row.Status.Foreground = System.Windows.Media.Brushes.Red; StatusText.Text = row.NameBox.Text + " connection failed: " + ex.Message; }
        }
        private async void LoadFile_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "Serial files (*.txt;*.csv)|*.txt;*.csv|All files (*.*)|*.*", Multiselect = false };
            if (dlg.ShowDialog() != true) return;
            try
            {
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                _fileQueue.Clear();
                // Scan the whole text instead of assuming one serial per line/cell.
                // This also supports CSV/text files where several records share a row.
                var fileText = File.ReadAllText(dlg.FileName);
                foreach (System.Text.RegularExpressions.Match match in
                    System.Text.RegularExpressions.Regex.Matches(fileText, @"(?<![A-Za-z0-9])[A-Za-z0-9]{18}(?![A-Za-z0-9])"))
                {
                    var val = match.Value;
                    if (seen.Add(val)) _fileQueue.Add(val);
                }
                if (_fileQueue.Count == 0)
                {
                    StatusText.Text = "No valid unique 18-character MLB SN entries found in the selected file.";
                    return;
                }
                SnTypeBox.SelectedIndex = 0;
                StatusText.Text = "Loaded " + _fileQueue.Count + " unique MLB SN entries from " + Path.GetFileName(dlg.FileName) + ".";
                if (rbAuto.IsChecked == true && _fileQueue.Count > 0)
                {
                    int index = TargetMachineBox.SelectedIndex;
                    if (index < 0 || index >= _machines.Count) index = 0;
                    await StartMachineAsync(_machines[index]);
                }
                else StatusText.Text += " Manual mode: choose machine, then START.";
            }
            catch (Exception ex) { StatusText.Text = "File load failed: " + ex.Message; }
        }
        private async void QueueData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var type = ((ComboBoxItem)SnTypeBox.SelectedItem).Content.ToString();
                int length = type == "MLB SN" ? 18 : type == "PANEL SN" ? 23 : 14;
                var serial = SerialBox.Text.Trim();
                if (serial.Length != length || !serial.All(char.IsLetterOrDigit)) { StatusText.Text = type + " must be exactly " + length + " alphanumeric characters."; return; }
                _fileQueue.Add(serial); StatusText.Text = "Queued 1 " + type + " entry.";
                if (rbAuto.IsChecked == true)
                {
                    int index = TargetMachineBox.SelectedIndex;
                    if (index < 0 || index >= _machines.Count) index = 0;
                    await StartMachineAsync(_machines[index]);
                }
                else StatusText.Text += " Manual mode: press START on the intended machine.";
            }
            catch (Exception ex) { StatusText.Text = "Queue error: " + ex.Message; }
        }
        private async void StartSelected_Click(object sender, RoutedEventArgs e)
        {
            int index = TargetMachineBox.SelectedIndex;
            if (index < 0 || index >= _machines.Count) index = 0;
            await StartMachineAsync(_machines[index]);
        }
        private async Task StartMachineAsync(MachineRow row)
        {
            if (_sending) { StatusText.Text = "A send operation is already in progress."; return; }
            if (_fileQueue.Count == 0) { StatusText.Text = "No data queued. Enter a serial or load an MLB file first."; return; }
            _sending = true;
            var batch = _fileQueue.ToList();
            var type = ((ComboBoxItem)SnTypeBox.SelectedItem).Content.ToString();
            try
            {
                int expected = type == "MLB SN" ? 18 : type == "PANEL SN" ? 23 : 14;
                int sent = 0;
                foreach (var serial in batch)
                {
                    if (serial.Length != expected || !serial.All(char.IsLetterOrDigit)) throw new InvalidOperationException("Queue contains a serial not matching " + type + " length " + expected + ". Clear queue and reload data.");
                    var command = "DATA|" + type + "|" + serial;
                    var response = await SendCommandAsync(row, command);
                    WriteLog(row, type, serial, response);
                    if (!response.StartsWith("OK", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("PDCA rejected data " + (sent + 1) + "/" + batch.Count + ": " + response);
                    sent++;
                    StatusText.Text = "Sending " + sent + "/" + batch.Count + " to " + row.NameBox.Text + " (" + row.IpBox.Text.Trim() + ")";
                }
                var startResponse = await SendCommandAsync(row, "START");
                WriteLog(row, type, "[START]", startResponse);
                StatusText.Text = row.NameBox.Text + ": sent " + sent + "/" + batch.Count + " item(s); " + startResponse;
                row.Status.Text = "START sent"; row.Status.Foreground = System.Windows.Media.Brushes.LightGreen;
                _fileQueue.Clear(); SerialBox.Clear();
            }
            catch (Exception ex) { WriteLog(row, type, "[BATCH ERROR]", ex.Message); StatusText.Text = "Send/START failed: " + ex.Message; row.Status.Text = "Error"; row.Status.Foreground = System.Windows.Media.Brushes.Red; }
            finally { _sending = false; }
        }
        private void WriteLog(MachineRow row, string type, string serial, string result)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_logPath));
                string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | Machine=" + Clean(row.NameBox.Text) + " | IP=" + Clean(row.IpBox.Text) + " | Port=" + Clean(row.PortBox.Text) + " | Type=" + Clean(type) + " | Data=" + Clean(serial) + " | Result=" + Clean(result);
                File.AppendAllText(_logPath, line + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }

        private async void SerialBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter || rbAuto.IsChecked != true) return;
            e.Handled = true;
            QueueData_Click(sender, new RoutedEventArgs());
        }

        private async void rbAuto_Checked(object sender, RoutedEventArgs e)
        {
            if (!IsLoaded || rbAuto.IsChecked != true || _fileQueue.Count == 0 || _sending) return;
            int index = TargetMachineBox.SelectedIndex;
            if (index < 0 || index >= _machines.Count) index = 0;
            await StartMachineAsync(_machines[index]);
        }
            catch (Exception ex) { StatusText.Text = "Could not open send log: " + ex.Message; }
        }

        private void ClearQueue_Click(object sender, RoutedEventArgs e) { _fileQueue.Clear(); SerialBox.Clear(); StatusText.Text = "Queued data cleared."; }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to close Communication Soft?", "Confirm Exit", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) { e.Cancel = true; return; }
            if (_clock != null) _clock.Stop();
            try { SaveSettings(); } catch { }
        }
    }
}
PDCA Sender + Communication Soft source bundle

Updates in this revision (limited to the requested Communication Soft / queue fixes):
- Communication Soft asks for confirmation before closing. Standard Windows title bar controls remain enabled: minimize, maximize/restore, close.
- Manual and Auto mode selectors are available. Manual mode queues entered data / loaded MLB file until START is pressed. Auto mode sends valid entered serials on Queue Data/Enter, and sends a loaded MLB file after it is validated.
- Serial validation: MLB SN = 18 alphanumeric characters; PANEL SN = 23; JIG SN = 14.
- Communication Soft records timestamp, target machine/IP/port, serial type, data, and result in Logs\communication-log.txt. Use Open Log to view it.
- Communication Soft reports progress for each queued item and sends all accepted DATA records before START.
- PDCA Sender's Communication Soft queue waits for a previous query/send to finish instead of silently dropping later queue entries when the app is busy.

Build requirements:
- Windows + Visual Studio with .NET Framework 4.8 Developer Pack.
- Open each project in its folder and build with Visual Studio, or use the included build script for the PDCA Sender project.
- This source bundle has been checked for ZIP integrity and XAML/XML well-formedness, but was not compiled in this environment and has not been tested against the user's actual server/network. Test on one machine first.
